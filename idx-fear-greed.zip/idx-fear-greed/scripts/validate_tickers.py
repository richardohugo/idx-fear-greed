"""
Quick yfinance validation for IDX80 tickers.

Run before deploying to catch any tickers that yfinance doesn't resolve
(e.g. new listings Yahoo hasn't indexed yet, or symbol mismatches).

Usage:
    python scripts/validate_tickers.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import yfinance as yf
from src.indicators import IDX80_TICKERS, JCI, USDIDR


def check_ticker(symbol: str) -> tuple[str, int, float | None]:
    """Return (symbol, bar_count, latest_close) or (symbol, 0, None) on failure."""
    try:
        df = yf.Ticker(symbol).history(period="1mo")
        if df.empty:
            return symbol, 0, None
        return symbol, len(df), float(df["Close"].iloc[-1])
    except Exception:
        return symbol, 0, None


def main():
    all_symbols = [JCI, USDIDR, *IDX80_TICKERS]
    print(f"Checking {len(all_symbols)} symbols on yfinance...\n")

    failed = []
    thin = []  # resolved but very few bars
    for sym in all_symbols:
        name, bars, price = check_ticker(sym)
        if bars == 0:
            print(f"  ✗ {name:12s}  NO DATA")
            failed.append(name)
        elif bars < 10:
            print(f"  ⚠ {name:12s}  only {bars} bars  close={price}")
            thin.append(name)
        else:
            print(f"  ✓ {name:12s}  {bars} bars  close={price}")

    print()
    print(f"Resolved: {len(all_symbols) - len(failed)}/{len(all_symbols)}")
    if failed:
        print(f"Failed:   {failed}")
        print("  → These tickers may be new listings not yet on Yahoo, or wrong symbols.")
        print("  → Remove from IDX80_TICKERS or check for alternative suffixes.")
    if thin:
        print(f"Thin:     {thin}")
        print("  → Recent IPOs; fine once they have more history.")


if __name__ == "__main__":
    main()
